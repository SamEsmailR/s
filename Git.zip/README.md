Git Cloud
=========
A Web frontend for a git server.

Using this aplication, users will be able to:
---------------------------------------------
* Create repositories.
* View files in repositories.
* Share respositories with other users.

Frontend Framerworks:
--------------------
* React JS

Backend Framerworks:
--------------------
* Flask
* Sql Alchemy

Deployment:
----------
* Docker

Screencast:
-----------
https://www.youtube.com/watch?v=W2i2J4bkQQA
